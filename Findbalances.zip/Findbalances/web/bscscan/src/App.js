import './App.css';
import contract from './ABI.json'
import { useEffect, useState } from 'react';
import { ethers } from 'ethers';
import { hexConcat, hexValue } from 'ethers/lib/utils';

const ContractAddress = "0xc473396969bb743f0f8cb17b26d6b18ccb671e6c";
const abi = contract.abi;

  function App() {
  const [currentAccount, setCurrentAccount] = useState(null);
  
  const checkWalletIsConnected = async () => { 
  	const { ethereum } = window;
  	
  	if (!ethereum)
  	{
  		return;
  	}
  	
  	const accounts = await ethereum.request({method: 'eth_accounts'});
  	
  	if(accounts.lenght !== 0)
  	{
  		const account = accounts[0];
  		setCurrentAccount(account);
  	}
  }

  const connectWalletHandler = async () => { 

  const { ethereum } = window;
  
  if (!ethereum) {
  	alert("Install Metamask!");
  }
  
  try {
  	const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
  	console.log("Address:", accounts[0]);
  	setCurrentAccount(accounts[0]);
  } catch(err) {
  		console.log(err);
  	}
  
  }
  let temparr = [];
  const checkHandler = async () => {
    //var addresses = "0xB255677f8a5CdC3D91dF2265ECEee288A8BF0970, 0x8eaeAca5Bfb3C176FD4DBDE0F206863271F5455a, 0x8b05804927b92243A8256eCaDBCd9AA1c416f540";
      let temp;
      var balancesarr = [];
      var input = document.getElementsByName('array[]');
      const { ethereum } = window;
      const provider = new ethers.providers.Web3Provider(ethereum);
      const signer = provider.getSigner();
      const Contract = new ethers.Contract(ContractAddress, abi, signer);

      for (var i = 0; i < input.length; i++) {
        var a = input[i];
        var k = a.value;
        balancesarr.push(k);  
      }
      for (var i = 0; i < input.length; i++) {
        var takePromise = Promise.all([Contract.etherBalances([balancesarr[i]])]).then(function([value]){
          var Object = value[0];
          var key = 0, i = 0;
          var _hex;
          for (key in Object) {
            i++;
            if(i === 2)
            break;
            if(Object.hasOwnProperty(key)) {
              var value = Object[key];
              _hex = value;
              SetHex(_hex);
            }
          }
        })
      }
      setTimeout(ShowBalances, 5000);
  }

  function SetHex(hex)
  {
      temparr.push(hex);
  }
  function ShowBalances()
  {
      const weiValue = 100000;
      let dec = [];
      const hexToDecimal = hex => parseInt(hex, 16);
      
      for(let i = 0; i < temparr.length; ++i){
        dec.push(hexToDecimal(temparr[i]));
        dec[i] = ethers.utils.formatEther(weiValue) + " ETH ";  
      }
      
      const ethValue = ethers.utils.formatEther(weiValue);

      document.getElementById("par").innerHTML = dec ;
      temparr.splice(0, temparr.length);
      dec.splice(0, dec.length);
  }

  const connectWalletButton = () => {
    return (
      <button onClick={connectWalletHandler} className='cta-button connect-wallet-button'>
        Connect Wallet
      </button>
    )
  }

  

  useEffect(() => {
    checkWalletIsConnected();
  }, [])

  return (
    <div className='main-app'>
      <h1></h1>
      <div>
        {connectWalletButton()}
       
      </div>
      <h1></h1>
      <div>
      <form className='' action="index.html" method="post">
        <input type="text" name="array[]"/>
        <input type="text" name="array[]"/>
        <input type="text" name="array[]"/>
        <input type="text" name="array[]"/>
        <input type="text" name="array[]"/>
        <h1></h1>
        <button type="button" name="button" onClick={checkHandler}className='cta-button check-button'>Send</button>
      </form>
      <p id="par"></p>
      </div>
    </div>
  )
}

export default App;
