const Contacts = artifacts.require("./BalanceScanner.sol");

module.exports = function(deployer) {
  deployer.deploy(Contacts);
};
